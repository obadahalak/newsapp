<title>تفاصيل الدورة</title>
@extends('Layout')
@section('content')
    <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">إضافة دورة جديدة</h3>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <                        
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
