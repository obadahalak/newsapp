<title>تفاصيل الدورة</title>
@extends('Layout')
@section('content')
    <div class="row row-sm mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title m-auto">تفاصيل الدورة</h3>
                </div>
                <div class="card-body">                    
                    
                </div>
            </div>
        </div>
    </div>
@endsection
